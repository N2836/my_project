#ifndef MAINTHIRDTEST_H
#define MAINTHIRDTEST_H

#include <QMainWindow>

namespace Ui {
class Mainthirdtest;
}

class Mainthirdtest : public QMainWindow
{
    Q_OBJECT

public:
    explicit Mainthirdtest(QWidget *parent = nullptr);
    ~Mainthirdtest();

private:
    Ui::Mainthirdtest *ui;
};

#endif // MAINTHIRDTEST_H
