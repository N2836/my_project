#ifndef HOME_C_H
#define HOME_C_H
#include <QVBoxLayout>
#include <QMainWindow>
#include <QWidget>
#include <QLabel>


#include <QSqlQuery>
#include <QSqlQueryModel>
\
#include <QString>
#include <QFileDialog>
#include <QPixmap>
#include <QByteArray>
#include <QBuffer>
#include <QMovie>
#include <QMediaPlayer>
#include <QDebug>
#include <QVideoWidget>

extern QString manger;
extern QString apply;
//extern int dark;
//extern QString F;
extern QString x1;
extern QString x2;
//extern int sw;
extern int chek;
extern QString name1;

namespace Ui {
class home_c;
}

class home_c : public QMainWindow
{
    Q_OBJECT

public:
    explicit home_c(QWidget *parent = nullptr);
    //void createButton(QVBoxLayout *mainLayout);
    ~home_c();
//public slots:
//    void receiveMessage(const QString &message);
private slots:
    void on_pushButton_clicked();


    void on_pushButton_2_clicked();
/*
    void on_pushButton_57_clicked();
        void on_pushButton_59_clicked();
         void on_pushButton_60_clicked();

         void on_pushButton_61_clicked();
           void on_pushButton_62_clicked();
             void on_pushButton_63_clicked();
              void on_pushButton_64_clicked();
              void on_pushButton_70_clicked();
                void on_pushButton_73_clicked();
                  void on_pushButton_72_clicked();
                   void on_pushButton_71_clicked();
                   void on_pushButton_79_clicked();
                     void on_pushButton_82_clicked();
                       void on_pushButton_80_clicked();
                        void on_pushButton_81_clicked();

                        void on_pushButton_89_clicked();
                        void on_pushButton_88_clicked();
*/

private:
    Ui::home_c *ui;
  //  void createButton();
/*
    void showImagePickerWindow(QLabel *label32);
    void loadImageFromDatabase();
    void showImagePickerWindow5(QLabel *label33);
    void loadImageFromDatabase5();
    void showImagePickerWindow4(QLabel *label34);
    void loadImageFromDatabase4();
    void showImagePickerWindow3(QLabel *label35);
    void loadImageFromDatabase3();
    void showImagePickerWindow2(QLabel *label36);
    void loadImageFromDatabase2();
*/

};

#endif // HOME_C_H
