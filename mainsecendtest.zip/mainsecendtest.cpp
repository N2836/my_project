#include "mainsecendtest.h"
#include "ui_mainsecendtest.h"
#include "QMessageBox"
#include "secendtest2.h"

//extern int dark;

Mainsecendtest::Mainsecendtest(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Mainsecendtest)
{
    ui->setupUi(this);
    ui->lineEdit->hide();
    ui->pushButton_2->hide();
       ui->pushButton->setStyleSheet("background-image: url(:/new/prefix1/pushbotton.jpg);color:white;");
ui->pushButton_2->setStyleSheet("background-image: url(:/new/prefix1/pushbotton.jpg);color:white;");
Mainsecendtest::setStyleSheet("background-image: url(:/new/prefix1/background1.jpg);");

    Mainsecendtest::isFullScreen();



   ui->lineEdit->setStyleSheet("background-image: url(:/new/prefix1/pushbotton.jpg);color:white;");

}

Mainsecendtest::~Mainsecendtest()
{
    delete ui;
}







void Mainsecendtest::on_pushButton_clicked()
{
    int r;
    r=rand()%10;
    switch(r) {
    case 0:
        QMessageBox::information(this,"cod information","pleas enter this cod:1354","ok");
        break;
    case 1:
        QMessageBox::information(this,"cod information","pleas enter this cod:6838","ok");
        break;
    case 2:
        QMessageBox::information(this,"cod information","pleas enter this cod:2288","ok");
        break;
    case 3:
        QMessageBox::information(this,"cod information","pleas enter this cod:9287","ok");
        break;
    case 4:
        QMessageBox::information(this,"cod information","pleas enter this cod:4682","ok");
        break;
    case 5:
        QMessageBox::information(this,"cod information","pleas enter this cod:4340","ok");
        break;
    case 6:
        QMessageBox::information(this,"cod information","pleas enter this cod:1947","ok");
        break;
    case 7:
        QMessageBox::information(this,"cod information","pleas enter this cod:6483","ok");
        break;
    case 8:
        QMessageBox::information(this,"cod information","pleas enter this cod:9017","ok");
        break;
    case 9:
        QMessageBox::information(this,"cod information","pleas enter this cod:7264","ok");
        break;
    }
    ui->pushButton->hide();
ui->lineEdit->show();
ui->pushButton_2->show();
}


void Mainsecendtest::on_pushButton_2_clicked()
{
    if(ui->lineEdit->text()=="7264"||ui->lineEdit->text()=="9017"||ui->lineEdit->text()=="6483"||ui->lineEdit->text()=="1947"||ui->lineEdit->text()=="4340"||ui->lineEdit->text()=="4682"||ui->lineEdit->text()=="9287"||ui->lineEdit->text()=="2288"||ui->lineEdit->text()=="6838"||ui->lineEdit->text()=="1354"){
        secendtest2 *w3 = new secendtest2;
        w3->show();
          this->close();
    }
    else {
        QMessageBox::warning(this,"warning cod","The code is wrong, please check again","try again");
        ui->lineEdit->clear();
        ui->pushButton->show();
    }
}

