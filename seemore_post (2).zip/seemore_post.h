#ifndef SEEMORE_POST_H
#define SEEMORE_POST_H

#include <QMainWindow>

//extern int dark;
extern QString user_name;
extern QString user;

namespace Ui {
class seemore_post;
}

class seemore_post : public QMainWindow
{
    Q_OBJECT

public:
    explicit seemore_post(QWidget *parent = nullptr);
    ~seemore_post();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_79_clicked();

    void on_pushButton_80_clicked();

    void on_pushButton_71_clicked();

    void on_pushButton_72_clicked();

    void on_pushButton_73_clicked();

    void on_pushButton_74_clicked();

    void on_pushButton_75_clicked();

    void on_pushButton_76_clicked();

    void on_pushButton_77_clicked();

    void on_pushButton_78_clicked();

private:
    Ui::seemore_post *ui;
};

#endif // SEEMORE_POST_H
