#ifndef LIKE_H
#define LIKE_H

#include "time1.h"
#include <string>

class Like {
public:
    std::string who_liked_ID;
    std::string like_ID;
    Time time;

    Like(std::string whoLiked, std::string likeId, Time t)
        : who_liked_ID(whoLiked), like_ID(likeId), time(t) {}
};

#endif // LIKE_H
