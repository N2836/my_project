#ifndef TIME_H
#define TIME_H

#include <string>

class Time {
public:
    std::string day;
    std::string month;
    std::string year;
    std::string hour;
    std::string minute;
    std::string second;

    Time(std::string d, std::string m, std::string y, std::string h, std::string min, std::string s)
        : day(d), month(m), year(y), hour(h), minute(min), second(s) {}
};

#endif // TIME_H
