
#include "home_c.h"
#include "ui_home_c.h"
#include "sign_company.h"
#include "home.h"
#include "company.h"
#include <QMessageBox>
#include <QScrollArea>
#include "creat_job.h"
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
#include "QSqlDatabase"

#include <QFileDialog>
#include <QPixmap>
#include <QMessageBox>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlError>
#include <QByteArray>
#include <QBuffer>
#include <QLabel>
#include <QVBoxLayout>
#include <QMediaPlayer>
#include <QVideoWidget>
#include <QGraphicsVideoItem>
#include <QAbstractVideoSurface>



extern QString manger;
extern QString x1;
extern QString x2;
extern QString apply;
//extern int dark;
//QString combined;

/*
QString i1;
QString i2;
QString i3;
QString i4;
QString i5;
*/


//extern QString F;
home_c::home_c(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::home_c)
{
    std::vector<std::string> follower;
       std::vector<std::string> following;
       std::vector<Post> post;
       std::vector<DirectMessage> dm;
       std::vector<Job> company_jobs;
       std::vector<Person> employees;
       std::vector<std::string> followers;

       // تبدیل QString به std::string
       std::string id = x1.toStdString();
       std::string number = x1.toStdString();
       std::string email = x2.toStdString();

       // ساخت شیء Company
       Company company("John", "Doe", "Software Developer", id, number, email, follower, following, std::move(post), std::move(dm), "Example Company", company_jobs, employees, followers);

       // مثال از استفاده از شیء company
       company.add_following("new_follower");
    ui->setupUi(this);
      home_c::setStyleSheet("background-image: url(:/new/prefix1/background1.jpg);");
      home_c::isFullScreen();
       ui->pushButton->setStyleSheet("background-image: url(:/new/prefix1/pushbotton.jpg);color:white;");
    ui->tabWidget->setTabText(0, tr("person"));
    ui->tabWidget->setTabText(1, tr("company"));
    QSqlDatabase database;
    database=QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\linkedin2.db");
    database.open();
ui->groupBox_2->hide();

}

home_c::~home_c()
{
    delete ui;
}



void home_c::on_pushButton_clicked()
{
    creat_job *w9 = new creat_job;
    w9->show();
      this->close();
}


















/*
#include "home_c.h"
#include "ui_home_c.h"
#include "sign_company.h"
#include "home.h"
#include "creat_job.h"

#include <QSqlQuery>
#include <QSqlError>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QPushButton>
#include <QMap>
#include <functional>
#include <QDebug>
//#include <QWidget>

extern QString manger;
extern QString apply;
extern QString F;

home_c::home_c(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::home_c)
{
    ui->setupUi(this);
    ui->tabWidget->setTabText(0, tr("person"));
    ui->tabWidget->setTabText(1, tr("company"));

    // Call the function to create buttons
    createButtons(); // Assuming you have a QVBoxLayout named verticalLayout in your UI
}

home_c::~home_c()
{
    delete ui;
}

void home_c::createButtons(QVBoxLayout *mainLayout) {
    // اجرای پرس‌وجو SQL
    QSqlQuery query;
    query.prepare("SELECT job_applicant FROM linkedin2 WHERE job_applicant = :searchValue");
    query.bindValue(":searchValue", F);

    // ایجاد یک QGroupBox برای نمایش دکمه‌ها
    QGroupBox *groupBox = new QGroupBox("Applicants", mainLayout->parentWidget());
    QVBoxLayout *layout = new QVBoxLayout(groupBox);

    // ایجاد یک نقشه برای نگهداری اسم‌ها و اشاره‌گرهای تابع
    QMap<QString, std::function<void()>> nameToFunctionMap;

    int count = 0;
    if (query.exec()) {
        while (query.next()) {
            QString name = query.value(0).toString();
            QPushButton *button = new QPushButton(name, groupBox);
            layout->addWidget(button);

            // ایجاد یک تابع برای هر دکمه
            std::function<void()> buttonFunction = [name]() {
                qDebug() << "Button clicked:" << name;
            };
            nameToFunctionMap[name] = buttonFunction;
            QObject::connect(button, &QPushButton::clicked, buttonFunction);

            count++;
        }
        qDebug() << "Number of records with job_applicant equal to" << F << "is:" << count;
    } else {
        qDebug() << "Error executing query:" << query.lastError().text();
    }

    // ایجاد دکمه‌های اضافی با استفاده از مقدار متغیر count
    for (int i = count; i < 10; i++) {
        QString name = QString("Button %1").arg(i + 1);
        QPushButton *button = new QPushButton(name, groupBox);
        layout->addWidget(button);

        // ایجاد یک تابع برای هر دکمه
        std::function<void()> buttonFunction = [name]() {
            qDebug() << "Button clicked:" << name;
        };
        nameToFunctionMap[name] = buttonFunction;
        QObject::connect(button, &QPushButton::clicked, buttonFunction);
    }

    mainLayout->addWidget(groupBox);
}

void home_c::on_pushButton_clicked()
{
    creat_job *w9 = new creat_job;
    w9->show();
}

*/






void home_c::on_pushButton_2_clicked()
{
    if(apply==x1||apply==x2){
        // ابتدا یک query برای خواندن اطلاعات از جدول linkedin2 آماده می‌کنیم
        QSqlQuery query;
        query.prepare("SELECT username, job_applycant FROM linkedin2");
        query.exec();

        // حالا در حین اجرای query، برای هر رکورد چک می‌کنیم که آیا job برابر x1 یا x2 است
        while (query.next()) {
            name1 = query.value("username").toString();
            QString job = query.value("job_applycant").toString();

            if (job == "x1" || job == "x2") {
                // اگر job برابر x1 یا x2 بود، یک لیبل جدید ایجاد می‌کنیم
                QLabel* label = new QLabel(name1);
                ui->verticalLayout->addWidget(label);

                // و دو پوش باتن برای قبول کردن و قبول نکردن ایجاد می‌کنیم
                QPushButton* acceptButton = new QPushButton("قبول کردن");
                QPushButton* rejectButton = new QPushButton("قبول نکردن");

                // این پوش باتن ها را به لیبل اضافه می‌کنیم
                QHBoxLayout* layout = new QHBoxLayout();
                layout->addWidget(acceptButton);
                layout->addWidget(rejectButton);
                label->setLayout(layout);
                // حالا اسلات های مربوط به پوش باتن ها را تعریف می‌کنیم
                connect(acceptButton, &QPushButton::clicked, [=]() {
                    // کد مربوط به قبول کردن را اینجا بنویسید
                  // sw=1;
                });

                connect(rejectButton, &QPushButton::clicked, [=]() {
                    // کد مربوط به قبول نکردن را اینجا بنویسید
                  // sw=2;
                });

            }
        }


    }else{
        QMessageBox::warning(this, "", "کسی درخواست شغل نداده", "ok");
    }
    QScrollArea* scrollArea = new QScrollArea(this);
        scrollArea->setWidgetResizable(true);
        scrollArea->setWidget(ui->verticalLayout->widget());
        ui->verticalLayout->setParent(scrollArea);
        ui->verticalLayout->update();
}










//*******************posts******************


/*

void home_c::showImagePickerWindow(QLabel *label32) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label32->setPixmap(pixmap);
        label32->setScaledContents(true); // فیکس کردن اندازه
    }
}


void home_c::on_pushButton_57_clicked()
{
    ui->label_32->show();
    showImagePickerWindow(ui->label_32);
    ui->pushButton_59->show();
    ui->pushButton_60->show();
}





void home_c::on_pushButton_59_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_32->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE company SET photo = :photo WHERE username = :username");
    query.bindValue(":username", "x2");
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home_c::on_pushButton_60_clicked()
{
    loadImageFromDatabase();
    ui->label_36->show();
    ui->pushButton_61->show();

    i1= ui->lineEdit_17->text();
    QSqlQuery cap;
    cap.prepare("UPDATE company SET caption=:caption WHERE username=:username");
    cap.bindValue(":caption", i1);
    cap.bindValue(":username", "x2");
    cap.exec();
}

void home_c::loadImageFromDatabase() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo FROM company WHERE username = :username");
    query.bindValue(":username", "x2");

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_32->setPixmap(pixmap);
        ui->label_32->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << "x2";
    }

    db.close();
}








void home_c::showImagePickerWindow2(QLabel *label36) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label36->setPixmap(pixmap);
        label36->setScaledContents(true); // فیکس کردن اندازه
    }
}


void home_c::on_pushButton_61_clicked()
{
    ui->label_36->show();
    showImagePickerWindow2(ui->label_36);
    ui->pushButton_70->show();
    ui->pushButton_79->show();
}





void home_c::on_pushButton_70_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_36->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE company SET photo_2 = :photo_2 WHERE username = :username");
    query.bindValue(":username", "x2");
    query.bindValue(":photo_2", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home_c::on_pushButton_79_clicked()
{
    loadImageFromDatabase2();
    ui->label_35->show();
    ui->pushButton_62->show();

    i2= ui->lineEdit_18->text();
    QSqlQuery cap;
    cap.prepare("UPDATE company SET caption_2=:caption_2 WHERE username=:username");
    cap.bindValue(":caption_2", i2);
    cap.bindValue(":username", "x2");
    cap.exec();
}

void home_c::loadImageFromDatabase2() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_2 FROM company WHERE username = :username");
    query.bindValue(":username", "x2");

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_36->setPixmap(pixmap);
        ui->label_36->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << "x2";
    }

    db.close();
}








void home_c::showImagePickerWindow3(QLabel *label35) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label35->setPixmap(pixmap);
        label35->setScaledContents(true); // فیکس کردن اندازه
    }
}


void home_c::on_pushButton_62_clicked()
{
    ui->label_35->show();
    showImagePickerWindow3(ui->label_35);
    ui->pushButton_71->show();
    ui->pushButton_80->show();
}





void home_c::on_pushButton_71_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_35->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE company SET photo_3 = :photo_3 WHERE username = :username");
    query.bindValue(":username", "x2");
    query.bindValue(":photo_3", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home_c::on_pushButton_80_clicked()
{
    loadImageFromDatabase3();
    ui->label_34->show();
    ui->pushButton_63->show();

    i3= ui->lineEdit_19->text();
    QSqlQuery cap;
    cap.prepare("UPDATE company SET caption_3=:caption_3 WHERE username=:username");
    cap.bindValue(":caption_3", i3);
    cap.bindValue(":username", "x2");
    cap.exec();
}

void home_c::loadImageFromDatabase3() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_3 FROM company WHERE username = :username");
    query.bindValue(":username", "x2");

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_35->setPixmap(pixmap);
        ui->label_35->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << "x2";
    }

    db.close();
}







void home_c::showImagePickerWindow4(QLabel *label34) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label34->setPixmap(pixmap);
        label34->setScaledContents(true); // فیکس کردن اندازه
    }
}


void home_c::on_pushButton_63_clicked()
{
    ui->label_34->show();
    showImagePickerWindow4(ui->label_34);
    ui->pushButton_72->show();
    ui->pushButton_81->show();
}





void home_c::on_pushButton_72_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_34->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE company SET photo_4 = :photo_4 WHERE username = :username");
    query.bindValue(":username", "x2");
    query.bindValue(":photo_4", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home_c::on_pushButton_81_clicked()
{
    loadImageFromDatabase4();
    ui->label_33->show();
    ui->pushButton_64->show();

    i4= ui->lineEdit_20->text();
    QSqlQuery cap;
    cap.prepare("UPDATE company SET caption_4=:caption_4 WHERE username=:username");
    cap.bindValue(":caption_4", i4);
    cap.bindValue(":username", "x2");
    cap.exec();
}

void home_c::loadImageFromDatabase4() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_4 FROM company WHERE username = :username");
    query.bindValue(":username", "x2");

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_34->setPixmap(pixmap);
        ui->label_34->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << "x2";
    }

    db.close();
}








void home_c::showImagePickerWindow5(QLabel *label33) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label33->setPixmap(pixmap);
        label33->setScaledContents(true); // فیکس کردن اندازه
    }
}


void home_c::on_pushButton_64_clicked()
{
    ui->label_33->show();
    showImagePickerWindow5(ui->label_33);
    ui->pushButton_73->show();
    ui->pushButton_82->show();
}





void home_c::on_pushButton_73_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_33->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE company SET photo_5 = :photo_5 WHERE username = :username");
    query.bindValue(":username", "x2");
    query.bindValue(":photo_5", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home_c::on_pushButton_82_clicked()
{
    loadImageFromDatabase5();
    ui->label_37->show();
    ui->pushButton_65->show();

    i5= ui->lineEdit_21->text();
    QSqlQuery cap;
    cap.prepare("UPDATE company SET caption_5=:caption_5 WHERE username=:username");
    cap.bindValue(":caption_5", i5);
    cap.bindValue(":username", "x2");
    cap.exec();
}

void home_c::loadImageFromDatabase5() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_5 FROM company WHERE username = :username");
    query.bindValue(":username", "x2");

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_33->setPixmap(pixmap);
        ui->label_33->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << "x2";
    }

    db.close();
}


*/


/*
void home_c::on_pushButton_89_clicked()
{
    ui->groupBox_2->show();

    QSqlQuery query;
    query.exec("SELECT companyname,username,employee_number,field FROM company WHERE rf='"+x1+"' OR rf='"+x2+"'");
    // page yesclick
    QSqlQueryModel *n = new QSqlQueryModel;
    n->setQuery(query);
    ui->tableView_6->setModel(n);

}


void home_c::on_pushButton_88_clicked()
{
    QString follow = ui -> lineEdit -> text();
        QSqlQuery q;
        q.exec("SELECT follower FROM company WHERE username ='"+x1+"' OR username ='"+x2+"'");
        QString tv;
        if (q.next()){
            tv = q.value(0).toString();
        }
        combined = follow + "/" + tv;
        QSqlQuery p;
        p.exec("UPDATE company SET follower = '"+combined+"' WHERE username ='"+x1+"' OR username ='"+x2+"'");

}

*/
