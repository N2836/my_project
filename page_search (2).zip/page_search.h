#ifndef PAGE_SEARCH_H
#define PAGE_SEARCH_H


#include <QMainWindow>
#include <QString>
#include <QLabel>

//extern int dark;
extern QString bio;
extern QString search;
extern QString user_name;
extern QString user;
namespace Ui {
class page_search;
}

class page_search : public QMainWindow
{
    Q_OBJECT

public:
    explicit page_search(QWidget *parent = nullptr);
    ~page_search();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::page_search *ui;
     void displayImage(QString username,QLabel* label);
};

#endif // PAGE_SEARCH_H
