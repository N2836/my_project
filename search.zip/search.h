#ifndef SEARCH_H
#define SEARCH_H

#include <QMainWindow>
#include <QSqlDatabase>

namespace Ui {
class Search;
}

class Search : public QMainWindow
{
    Q_OBJECT

public:
    explicit Search(QWidget *parent = nullptr);
    ~Search();

private slots:
    void on_searchButton_clicked();

private:
    Ui::Search *ui;
    QSqlDatabase database;
};

#endif // SEARCH_H

