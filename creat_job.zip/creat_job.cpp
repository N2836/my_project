#include "creat_job.h"
#include "ui_creat_job.h"
#include <QString>
#include "home.h"
#include "QMessageBox"
#include "QtSql/QSqlDatabase"
#include "QtSql/QSqlError"
#include "QtSql/QSqlQuery"
#include "QDebug"
#include "yes_click.h"
#include "job.h"
#include "sign_company.h"
//QString F;
extern QString x2;
QString a1;
QString a2;
QString a3;
QString a4;
QString a5;
QString a6;
QString a7;
QString a8;
QString a9;
extern QString user;
//extern int dark;
//QString D;
 //extern QString F;
extern QString x1;
creat_job::creat_job(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::creat_job)
{
    ui->setupUi(this);

    creat_job::setStyleSheet("background-image: url(:/new/prefix1/background1.jpg);");
    creat_job::isFullScreen();
        ui->pushButton->setStyleSheet("background-image: url(:/new/prefix1/pushbotton.jpg);color:white;");
          ui->pushButton_2->setStyleSheet("background-image: url(:/new/prefix1/pushbotton.jpg);color:white;");
            ui->lineEdit->setStyleSheet("background-image: url(:/new/prefix1/pushbotton.jpg);color:white;");
              ui->lineEdit_2->setStyleSheet("background-image: url(:/new/prefix1/pushbotton.jpg);color:white;");
                //ui->label->setStyleSheet("background-image: url(:/new/prefix1/pushbotton.jpg);color:white;");
                //  ui->label_2->setStyleSheet("background-image: url(:/new/prefix1/pushbotton.jpg);color:white;");


              QStringList workplace_type = {"", "On site", "Remote", "Hybrid"};
              ui->comboBox->addItems(workplace_type);

              QStringList job_type = {"", "Full-time", "Part-time", "Contract", "Temporary", "Other", "Volunteer", "Internship"};
              ui->comboBox_2->addItems(job_type);


    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\linkedin2.db");
    if (!database.open()) {
        qDebug() << "Error: Connection with database failed" << database.lastError();
        QMessageBox::critical(this, "Database Error", "Failed to connect to the database");
    } else {
        qDebug() << "Database: Connection ok";
    }
    std::vector<std::string> skills_required; // این باید بر اساس ورودی‌های کاربر پر شود
        Job new_job(a1.toStdString(), a2.toStdString(), user.toStdString(), skills_required, a8.toStdString(), a4.toStdString(), a9.toStdString());

        // استفاده از شیء new_job (در اینجا فقط به عنوان مثال)
        qDebug() << "New job created with job name:" << QString::fromStdString(new_job.job_name);
}

creat_job::~creat_job()
{
    delete ui;
}
void creat_job::on_pushButton_clicked()
{
   a1= ui->lineEdit->text();
   a2= ui->lineEdit_2->text();
   a3= ui->lineEdit_3->text();
   a4= ui->lineEdit_4->text();
   a5= ui->lineEdit_5->text();
   a6= ui->lineEdit_6->text();
   a7= ui->lineEdit_7->text();
   a8 = ui->comboBox->currentText();
   a9 = ui->comboBox_2->currentText();
   if (a1.isEmpty() || a2.isEmpty() || a3.isEmpty() || a4.isEmpty() || a5.isEmpty() || a6.isEmpty() || a7.isEmpty() || a8.isEmpty() || a9.isEmpty()) {
       QMessageBox::warning(this, "", "Please fill in all the blanks", "OK");
       return;
   }
}

void creat_job::on_pushButton_2_clicked()
{



    QSqlQuery query;
    query.exec("UPDATE job SET salary = '"+a1+"', company = '"+a2+"', skil = '"+a3+"', work_place = '"+a4+"', location_company = '"+a5+"', employee_field = '"+a6+"', degree = '"+a7+"' , workplace_type = '"+a8+"' , job_type = '"+a9+"'   WHERE username = '"+x1+"' OR username = '"+x2+"'");
    /*
    query.bindValue(":salary", a1);
     query.bindValue(":company", a2);
      query.bindValue(":skil", a3);
       query.bindValue(":work_place", a4);
        query.bindValue(":location_company", a5);
         query.bindValue(":employee_field", a6);
          query.bindValue(":degree", a7);
          query.bindValue(":username", x1);
          */

    qDebug() << "Executing query: " << query.executedQuery(); // Print the final query

    if (!query.exec()) {
        qDebug() << "Update error:" << query.lastError().text(); // Print detailed error message
    } else {
        QMessageBox::information(this, "", "Data updated successfully", "OK");
    }
}






