
#ifndef MAINSECENDTEST_H
#define MAINSECENDTEST_H

#include <QMainWindow>

//extern int dark;

QT_BEGIN_NAMESPACE
namespace Ui { class Mainsecendtest; }
QT_END_NAMESPACE

class Mainsecendtest : public QMainWindow
{
    Q_OBJECT

public:
    Mainsecendtest(QWidget *parent = nullptr);
    ~Mainsecendtest();
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Mainsecendtest *ui;
};
#endif // MAINSECENDTEST_H
