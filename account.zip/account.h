// account.h
#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>
#include <vector>
#include <QString>
#include "person.h" // فرض بر اینکه کلاس Person قبلا تعریف شده است
#include "post.h" // فرض بر اینکه کلاس Post قبلا تعریف شده است
#include "direct.h" // فرض بر اینکه کلاس DirectMessage قبلا تعریف شده است

class Account : public Person {
private:
    std::string account_ID; // username
    std::string phone_number;
    std::string email;
    std::vector<std::string> connection; // follow
    std::vector<std::string> following;
    std::vector<Post> posts; // آرایه پویا از پست‌ها
    std::vector<DirectMessage> DM; // آرایه پویا از پیام‌های مستقیم
public:
    // سازنده با آرگومان‌ها (Parameterized Constructor)
    Account(const std::string& firstname, const std::string& lastname, const std::string& skill,
            const std::string& account_ID, const std::string& phone_number, const std::string& email,
            const std::vector<std::string>& connection, const std::vector<std::string>& following,
            std::vector<Post>&& posts, std::vector<DirectMessage>&& DM)
        : Person(firstname, lastname, skill),
          account_ID(account_ID), phone_number(phone_number), email(email),
          connection(connection), following(following), posts(std::move(posts)), DM(std::move(DM)) {}

    void add_following(QString p) {
        std::string p1 = p.toStdString();
        connection.push_back(p1);
    }
};

#endif // ACCOUNT_H
