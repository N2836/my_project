#include "home.h"
#include "ui_home.h"
#include "page_search.h"
#include "account.h"
#include "seemore_post.h"
#include <QFileDialog>
#include <QPixmap>
#include <QMessageBox>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlError>
#include <QByteArray>
#include <QBuffer>
#include <QLabel>
#include <QVBoxLayout>
#include <QMediaPlayer>
#include <QVideoWidget>
#include <QGraphicsVideoItem>
#include <QAbstractVideoSurface>
#include <vector>
#include "sign_company.h"
//#include <qstyleditemdelegate.h>
//#include <QPainter>



/*
class ImageDelegate : public QStyledItemDelegate {
public:
    ImageDelegate(QObject *parent = nullptr) : QStyledItemDelegate(parent) {}

    void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const override {
        if (index.column() == 1) { // فرض می‌کنیم ستون عکس ستون دوم است
            QByteArray byteArray = index.data().toByteArray();
            QPixmap pixmap;
            pixmap.loadFromData(byteArray);
            painter->drawPixmap(option.rect, pixmap);
        } else {
            QStyledItemDelegate::paint(painter, option, index);
        }
    }
};

*/



extern QString l6;
extern QString user_name;
extern QString user;
QString f;
QString mix;
QByteArray byteArray;
extern  QString l3;
QString fileName;
extern QString name1;
//extern int sw;
QString A;
QString test;
QString test2;
QString combined;
QByteArray byte;
extern int chek;
extern QString f6;
extern QString l7;

QString i1;
QString i2;
QString i3;
QString i4;
QString i5;
QString i6;
QString i7;
QString i8;
QString i9;
QString i10;


home::home(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::home)
{
    std::string id = user.toStdString();
        std::string number = l7.toStdString();
        std::string email = l3.toStdString();

        // تعریف و مقداردهی اولیه آرایه‌های پویا
        std::vector<std::string> follower;
        std::vector<std::string> following;
        std::vector<Post> post;
        std::vector<DirectMessage> dm;

        // ساخت شیء Account
        Account p1("John", "Doe", "Software Developer", id, number, email, follower, following, std::move(post), std::move(dm));

        // مثال از استفاده از شیء p1
        p1.add_following("new_follower");
    ui->setupUi(this);
    ui->groupBox_3->hide();
    ui->pushButton_5->hide();
    ui->tableView_2->hide();
    ui->groupBox_2->hide();
    ui->tabWidget_2->hide();
    ui->groupBox_4->hide();
    ui->groupBox_5->hide();

    ui->label_6->hide();
    ui->label_9->hide();
    ui->label_13->hide();
    ui->label_14->hide();
    ui->label_15->hide();
    ui->label_16->hide();
    ui->label_24->hide();
    ui->label_25->hide();
    ui->label_26->hide();
    ui->label_27->hide();

    ui->pushButton_11->hide();
    ui->pushButton_12->hide();
    ui->pushButton_22->hide();
    ui->pushButton_23->hide();
    ui->pushButton_24->hide();
    ui->pushButton_25->hide();
    ui->pushButton_26->hide();
    ui->pushButton_27->hide();
    ui->pushButton_28->hide();
    ui->pushButton_29->hide();
    ui->pushButton_30->hide();
    ui->pushButton_31->hide();
    ui->pushButton_32->hide();
    ui->pushButton_33->hide();
    ui->pushButton_34->hide();
    ui->pushButton_35->hide();
    ui->pushButton_36->hide();

    ui->pushButton_44->hide();
    ui->pushButton_45->hide();
    ui->pushButton_46->hide();
    ui->pushButton_47->hide();
    ui->pushButton_48->hide();
    ui->pushButton_49->hide();
    ui->pushButton_50->hide();
    ui->pushButton_51->hide();
    ui->pushButton_52->hide();
    ui->pushButton_53->hide();
    ui->pushButton_54->hide();
    ui->pushButton_55->hide();


    ui->tabWidget->setTabText(0,tr("My Network"));
    ui->tabWidget->setTabText(1,tr("Jobs"));
    ui->tabWidget->setTabText(2,tr("Messaging"));
    ui->tabWidget->setTabText(3,tr("Home"));
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("d:\\linkedin2.db");
    if (!database.open()) {
        qDebug() << "Error: Connection with database failed" << database.lastError();
        QMessageBox::critical(this, "Database Error", "Failed to connect to the database");
    } else {
        qDebug() << "Database: Connection ok";
    }

}

home::~home()
{
    delete ui;
}


/*
void home::saveGifToDatabase(const QByteArray& gifData, const QString& username)
{
    // اتصال به دیتابیس اسکیو لایت
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("your_database.db");
    db.open();

    // ذخیره گیف در دیتابیس
    QSqlQuery query;
    query.prepare("INSERT INTO post (gif, user) VALUES (:gif, :user)");
    query.bindValue(":gif", gifData);
    query.bindValue(":user", username);
    if (query.exec()) {
        qDebug() << "GIF saved successfully.";
    } else {
        qDebug() << "Failed to save GIF:" << query.lastError().text();
    }

    db.close();
}
*/




void home::saveGifToDatabase(const QByteArray& gifData, const QString& username)
{
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("your_database.db");
    if (!db.open()) {
        QMessageBox::critical(this, tr("Error"), tr("Failed to open database."));
        return;
    }

    // ذخیره گیف در دیتابیس
    QSqlQuery query;
    query.prepare("INSERT INTO post (gif, user) VALUES (:gif, :user)");
    query.bindValue(":gif", gifData);
    query.bindValue(":user", username);
    if (!query.exec()) {
        QMessageBox::critical(this, tr("Error"), tr("Failed to save GIF: ") + query.lastError().text());
    } else {
        QMessageBox::information(this, tr("Success"), tr("GIF saved successfully."));
    }

    db.close();
}



QByteArray home::getGifDataFromSomewhereElse()
{
    // کد برای گرفتن داده گیف از جایی که قبلا ذخیره شده است
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open GIF"), "", tr("GIF Files (*.gif)"));
    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (file.open(QIODevice::ReadOnly)) {
            return file.readAll();
        }
    }
    return QByteArray(); // در صورت عدم انتخاب فایل، یک آرایه خالی برمی‌گرداند
}


void home::showImagePickerWindow(QLabel *label6) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label6->setPixmap(pixmap);
        label6->setScaledContents(true); // فیکس کردن اندازه
    }
}

void home::showGifPickerWindow(QLabel *label7)
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open GIF"), "", tr("GIF Files (*.gif)"));
    if (!fileName.isEmpty()) {
        QMovie *movie = new QMovie(fileName);
        if (!movie->isValid()) {
            QMessageBox::warning(this, tr("Error"), tr("The selected file is not a valid GIF."));
            delete movie;
           // label7->setScaledContents(true);
            return;
        }
        movie->setScaledSize(label7->size());
        label7->setMovie(movie);
        movie->start();
    }
}

void home::on_pushButton_2_clicked()
{
    search = ui->lineEdit->text();
    QSqlQuery q;

    q.exec("SELECT username FROM linkedin2 WHERE username ='" + search + "'");
    if (q.next()) {
        ui->groupBox_2->show();
        ui->label_8->setText(search);
    } else {
        QMessageBox::warning(this, "", "Not available in the list", "try again");
        ui->groupBox_2->hide();
    }
}

void home::on_pushButton_3_clicked()
{
    page_search *w4 = new page_search;
    w4->show();
}
void home::on_pushButton_4_clicked()
{
    QSqlQuery q;
    q.exec("SELECT salary, company, skil, work_place , location_company FROM job WHERE employee_field = '"+l6+"' OR employee_field = '"+f6+"' LIMIT 3");


    QSqlQueryModel *m = new QSqlQueryModel;
    m->setQuery(q);
    ui->tableView->setModel(m);
    ui->pushButton_5->show();
    ui->groupBox_3->show();
    if (name1 == user || name1 == user_name){
        if (chek == 1){
            QMessageBox::information( this , "","You are not accepted" , "ok");
            ui->pushButton_7->setText("apply");
            int num;
            QSqlQuery q;
            q.exec("SELECT employee_number FROM company WHERE companyname = '"+apply+"' ");
            if(q.next()){
                 num = q.value(0).toInt();
            }
         num++;
           QSqlQuery query;
           query.prepare("UPDATE company SET employee_number = :num1 WHERE companyname = :apply");
           query.bindValue(":num1", num);
           query.bindValue(":apply", apply);

        } else if (chek == 2) {
            QMessageBox::information( this , "","You are accepted" , "ok");
            ui->pushButton_7->setText("apply");
        }
    }
}

void home::on_pushButton_5_clicked()
{
    ui->tableView_2->show();
    QSqlQuery p;
   p.exec("SELECT salary, company, skil, work_place , location_company FROM job WHERE employee_field = '"+l6+"' OR employee_field = '"+f6+"' LIMIT -1 OFFSET 3");
    QSqlQueryModel *n = new QSqlQueryModel;
    n->setQuery(p);
    ui->tableView_2->setModel(n);
}

void home::on_pushButton_6_clicked()
{
    apply = ui->lineEdit_2->text();
    if (apply.isEmpty()) {
        QMessageBox::warning(this, "", "Please fill in all the blanks", "OK");
        return;
    }
}

void home::on_pushButton_7_clicked()
{
    ui->pushButton_7->setText("pending");
    QSqlQuery query;

    query.exec("UPDATE linkedin2 SET job_applycant= '" + apply + "' WHERE username = '" + user + "' OR username = '" + user_name + "'");
    //query.bindValue(":username", name);
    //query.bindValue(":job_applycant", apply);
}

void home::on_pushButton_8_clicked()
{
    ui->label_6->show();
    showImagePickerWindow(ui->label_6);
    ui->pushButton_11->show();
    ui->pushButton_12->show();
}

void home::on_pushButton_9_clicked()
{
    showGifPickerWindow(ui->label_7);
}

void home::on_pushButton_11_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_6->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET photo = :photo WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }



    db.close();
}

void home::on_pushButton_12_clicked()
{

    loadImageFromDatabase();
    ui->label_9->show();
    ui->pushButton_22->show();

    i1= ui->lineEdit_7->text();
    QSqlQuery cap;
    cap.prepare("UPDATE post SET caption=:caption WHERE username=:username");
    cap.bindValue(":caption", i1);
    cap.bindValue(":username", user);
    cap.exec();

}

void home::loadImageFromDatabase() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_6->setPixmap(pixmap);
        ui->label_6->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << user;
    }

    db.close();
}

void home::on_pushButton_clicked()
{


    QSqlQuery o;
    o.exec("SELECT username, post, field FROM linkedin2 WHERE username = '"+user_name+"'");


    QSqlQueryModel *m = new QSqlQueryModel;
    m->setQuery(o);
    ui->tableView_5->setModel(m);


    ui->tabWidget_2->show();
    QSqlQuery query;
    query.exec("SELECT profile FROM linkedin2 WHERE username = '"+user+"' OR username ='"+user_name+"'");
    if (query.next()) {
        QByteArray imageData = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(imageData);
        ui->label_10->setPixmap(pixmap);
        ui->label_10->setScaledContents(true);


        // پرس و جو برای دریافت عکس مربوط به کاربر
        QSqlQuery query;
        query.prepare("SELECT photo FROM post WHERE username = :username");
        query.bindValue(":username", user_name);
        query.exec();

        if (query.next()) {
            // دریافت داده عکس از دیتابیس
            QByteArray imageData = query.value("photo").toByteArray();

            // تبدیل داده عکس به QPixmap و نمایش در لیبل
            QPixmap pixmap;
            pixmap.loadFromData(imageData);
            ui->label_11->setPixmap(pixmap);
            ui->label_11->setScaledContents(true);
        }





        QSqlQuery q;
        q.prepare("SELECT photo_2 FROM post WHERE username = :username");
        q.bindValue(":username", user_name);
        q.exec();

        if (q.next()) {
            // دریافت داده عکس از دیتابیس
            QByteArray imageData = q.value("photo_2").toByteArray();

            // تبدیل داده عکس به QPixmap و نمایش در لیبل
            QPixmap pixmap;
            pixmap.loadFromData(imageData);
            ui->label_17->setPixmap(pixmap);
            ui->label_17->setScaledContents(true);
        }




        QSqlQuery h;
        h.prepare("SELECT photo_3 FROM post WHERE username = :username");
        h.bindValue(":username", user_name);
        h.exec();

        if (h.next()) {
            // دریافت داده عکس از دیتابیس
            QByteArray imageData = h.value("photo_3").toByteArray();

            // تبدیل داده عکس به QPixmap و نمایش در لیبل
            QPixmap pixmap;
            pixmap.loadFromData(imageData);
            ui->label_18->setPixmap(pixmap);
            ui->label_18->setScaledContents(true);
        }




        QSqlQuery d;
        d.prepare("SELECT photo_4 FROM post WHERE username = :username");
        d.bindValue(":username", user_name);
        d.exec();

        if (d.next()) {
            // دریافت داده عکس از دیتابیس
            QByteArray imageData = d.value("photo_4").toByteArray();

            // تبدیل داده عکس به QPixmap و نمایش در لیبل
            QPixmap pixmap;
            pixmap.loadFromData(imageData);
            ui->label_19->setPixmap(pixmap);
            ui->label_19->setScaledContents(true);
        }


        QSqlQuery y;
        y.prepare("SELECT photo_5 FROM post WHERE username = :username");
        y.bindValue(":username", user_name);
        y.exec();

        if (y.next()) {
            // دریافت داده عکس از دیتابیس
            QByteArray imageData = y.value("photo_5").toByteArray();

            // تبدیل داده عکس به QPixmap و نمایش در لیبل
            QPixmap pixmap;
            pixmap.loadFromData(imageData);
            ui->label_20->setPixmap(pixmap);
            ui->label_20->setScaledContents(true);
        }



        QSqlQuery r;
        r.prepare("SELECT photo_6 FROM post WHERE username = :username");
        r.bindValue(":username", user_name);
        r.exec();

        if (r.next()) {
            // دریافت داده عکس از دیتابیس
            QByteArray imageData = r.value("photo_6").toByteArray();

            // تبدیل داده عکس به QPixmap و نمایش در لیبل
            QPixmap pixmap;
            pixmap.loadFromData(imageData);
            ui->label_21->setPixmap(pixmap);
            ui->label_21->setScaledContents(true);
        }


        QSqlQuery f;
        f.prepare("SELECT photo_7 FROM post WHERE username = :username");
        f.bindValue(":username", user_name);
        f.exec();

        if (f.next()) {
            // دریافت داده عکس از دیتابیس
            QByteArray imageData = f.value("photo_7").toByteArray();

            // تبدیل داده عکس به QPixmap و نمایش در لیبل
            QPixmap pixmap;
            pixmap.loadFromData(imageData);
            ui->label_28->setPixmap(pixmap);
            ui->label_28->setScaledContents(true);
        }



    QSqlQuery l;
    l.prepare("SELECT photo_8 FROM post WHERE username = :username");
    l.bindValue(":username", user_name);
    l.exec();

    if (l.next()) {
        // دریافت داده عکس از دیتابیس
        QByteArray imageData = l.value("photo_8").toByteArray();

        // تبدیل داده عکس به QPixmap و نمایش در لیبل
        QPixmap pixmap;
        pixmap.loadFromData(imageData);
        ui->label_29->setPixmap(pixmap);
        ui->label_29->setScaledContents(true);
    }


    QSqlQuery e;
    e.prepare("SELECT photo_9 FROM post WHERE username = :username");
    e.bindValue(":username", user_name);
    e.exec();

    if (e.next()) {
        // دریافت داده عکس از دیتابیس
        QByteArray imageData = e.value("photo_9").toByteArray();

        // تبدیل داده عکس به QPixmap و نمایش در لیبل
        QPixmap pixmap;
        pixmap.loadFromData(imageData);
        ui->label_30->setPixmap(pixmap);
        ui->label_30->setScaledContents(true);
    }


    QSqlQuery t;
    t.prepare("SELECT photo_10 FROM post WHERE username = :username");
    t.bindValue(":username", user_name);
    t.exec();

    if (t.next()) {
        // دریافت داده عکس از دیتابیس
        QByteArray imageData = t.value("photo_10").toByteArray();

        // تبدیل داده عکس به QPixmap و نمایش در لیبل
        QPixmap pixmap;
        pixmap.loadFromData(imageData);
        ui->label_31->setPixmap(pixmap);
        ui->label_31->setScaledContents(true);
    }
  }
}


void home::on_pushButton_16_clicked()
{
     showImagePickerWindow(ui->label_10);
}


void home::on_pushButton_18_clicked()
{

    const QPixmap *pixmapPtr = ui->label_10->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "PNG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    }
    else {
        qDebug() << "Database: connection ok";
    }

    // ذخیره عکس در جدول linkedin2
    QSqlQuery query;
    query.prepare("UPDATE linkedin2 SET profile = :photo WHERE username = :username OR username = :username2");
    query.bindValue(":photo", byteArray);
    query.bindValue(":username", user);
    query.bindValue(":username2", user_name);
    if (!query.exec()) {
        qDebug() << "Error executing query:" << query.lastError().text();
    }
    else {
        qDebug() << "Image saved to linkedin2 table successfully.";
    }


    db.close();

}




void home::on_pushButton_19_clicked()
{
    bio=ui->lineEdit_4->text();
        QSqlQuery Q;
        Q.exec("UPDATE linkedin2 SET biography='"+bio+"' WHERE username = '"+user+"' OR username ='"+user_name+"' ");
        //Q.bindValue(":bio", bio);
        //Q.bindValue(":username", user);
        //Q.bindValue(":username2", user_name);


}






void home::on_pushButton_13_clicked() // برای ذخیره گیف
{
    // گرفتن QByteArray از QLabel
    const QPixmap *pixmapPtr = ui->label_7->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No GIF in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "GIF")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره گیف
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET gif = :gif WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":gif", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update GIF in database: " << query.lastError();
    } else {
        qDebug() << "GIF updated successfully";
    }

    db.close();
}

void home::on_pushButton_21_clicked() // برای بارگذاری گیف
{
    loadGifFromDatabase();
}

void home::loadGifFromDatabase() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن گیف
    QSqlQuery query;
    query.prepare("SELECT gif FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch GIF from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_7->setPixmap(pixmap);
        ui->label_7->setScaledContents(true);
    } else {
        qDebug() << "No GIF found for username: " << user;
    }

   // db.close();
}








void home::on_pushButton_20_clicked()
{
    // پرس و جو برای دریافت عکس مربوط به کاربر
    QSqlQuery query;
    query.prepare("SELECT photo FROM post WHERE username = :username");
    query.bindValue(":username", user_name);
    query.exec();

    if (query.next()) {
        // دریافت داده عکس از دیتابیس
        QByteArray imageData = query.value("photo").toByteArray();

        // تبدیل داده عکس به QPixmap و نمایش در لیبل
        QPixmap pixmap;
        pixmap.loadFromData(imageData);
        ui->label->setPixmap(pixmap);
        ui->label->setScaledContents(true);
    }

   // db.close();


}


void home::on_pushButton_10_clicked() {
    // باز کردن دیالوگ انتخاب فایل
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open Video"), "/", tr("Video Files (*.mp4 *.avi *.mov)"));

    if (!fileName.isEmpty()) {
        qDebug() << "Selected file:" << fileName;

        // ایجاد QMediaPlayer و QVideoWidget به صورت محلی
        QMediaPlayer* player = new QMediaPlayer(this); // یا QScopedPointer<QMediaPlayer> player(new QMediaPlayer(this));
        QVideoWidget* videoWidget = new QVideoWidget(this); // یا QScopedPointer<QVideoWidget> videoWidget(new QVideoWidget(this));

        // تنظیم خروجی ویدیو به ویجت
        player->setVideoOutput(videoWidget);

        // افزودن QVideoWidget به لایوت موجود
        if (ui->verticalLayout) { // اطمینان از وجود verticalLayout
            ui->verticalLayout->addWidget(videoWidget);
        }

        // تنظیم منبع ویدیو و شروع پخش
        player->setMedia(QUrl::fromLocalFile(fileName));
        player->play();

        if (player->state() != QMediaPlayer::PlayingState) {
            qDebug() << "Failed to start playback.";
        }
    } else {
        qDebug() << "No file selected.";
    }
}








//**********************************posts********************************




void home::showImagePickerWindow2(QLabel *label9) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label9->setPixmap(pixmap);
        label9->setScaledContents(true);
    }
}

void home::on_pushButton_22_clicked()
{
    showImagePickerWindow2(ui->label_9);
    ui->pushButton_23->show();
    ui->pushButton_24->show();
}

void home::on_pushButton_23_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_9->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET photo_2 = :photo WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home::on_pushButton_24_clicked()
{
    loadImageFromDatabase2();
    ui->label_13->show();
    ui->pushButton_25->show();
    i2= ui->lineEdit_8->text();
    QSqlQuery cap;
    cap.prepare("UPDATE post SET caption_2=:caption_2 WHERE username=:username");
    cap.bindValue(":caption_2", i2);
    cap.bindValue(":username", user);
    cap.exec();
}

void home::loadImageFromDatabase2() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_2 FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_9->setPixmap(pixmap);
        ui->label_9->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << user;
    }

    db.close();
}








void home::showImagePickerWindow3(QLabel *label13) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label13->setPixmap(pixmap);
        label13->setScaledContents(true);
    }
}

void home::on_pushButton_25_clicked()
{
    showImagePickerWindow3(ui->label_13);
     ui->pushButton_26->show();
      ui->pushButton_27->show();
}

void home::on_pushButton_26_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_13->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET photo_3 = :photo WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home::on_pushButton_27_clicked()
{
    loadImageFromDatabase3();
     ui->label_14->show();
     ui->pushButton_28->show();
     i3= ui->lineEdit_9->text();
     QSqlQuery cap;
     cap.prepare("UPDATE post SET caption_3=:caption_3 WHERE username=:username");
     cap.bindValue(":caption_3", i3);
     cap.bindValue(":username", user);
     cap.exec();
}

void home::loadImageFromDatabase3() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_3 FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_13->setPixmap(pixmap);
        ui->label_13->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << user;
    }

    db.close();
}






void home::showImagePickerWindow4(QLabel *label14) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label14->setPixmap(pixmap);
        label14->setScaledContents(true);
    }
}

void home::on_pushButton_28_clicked()
{
    showImagePickerWindow4(ui->label_14);
    ui->pushButton_29->show();
    ui->pushButton_30->show();
}

void home::on_pushButton_29_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_14->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET photo_4 = :photo WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home::on_pushButton_30_clicked()
{
    loadImageFromDatabase4();
    ui->label_15->show();
    ui->pushButton_31->show();
    i4= ui->lineEdit_10->text();
    QSqlQuery cap;
    cap.prepare("UPDATE post SET caption_4=:caption_4 WHERE username=:username");
    cap.bindValue(":caption_4", i4);
    cap.bindValue(":username", user);
    cap.exec();
}

void home::loadImageFromDatabase4() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_4 FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_14->setPixmap(pixmap);
        ui->label_14->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << user;
    }

    db.close();
}







void home::showImagePickerWindow5(QLabel *label15) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label15->setPixmap(pixmap);
        label15->setScaledContents(true);
    }
}

void home::on_pushButton_31_clicked()
{
    showImagePickerWindow5(ui->label_15);
    ui->pushButton_32->show();
    ui->pushButton_33->show();
}

void home::on_pushButton_32_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_15->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET photo_5 = :photo WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home::on_pushButton_33_clicked()
{
    loadImageFromDatabase5();
    ui->label_16->show();
    ui->pushButton_34->show();
    i5= ui->lineEdit_11->text();
    QSqlQuery cap;
    cap.prepare("UPDATE post SET caption_5=:caption_5 WHERE username=:username");
    cap.bindValue(":caption_5", i5);
    cap.bindValue(":username", user);
    cap.exec();
}

void home::loadImageFromDatabase5() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_5 FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_15->setPixmap(pixmap);
        ui->label_15->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << user;
    }

    db.close();
}





void home::showImagePickerWindow6(QLabel *label16) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label16->setPixmap(pixmap);
        label16->setScaledContents(true);
    }
}

void home::on_pushButton_34_clicked()
{
    showImagePickerWindow6(ui->label_16);
        ui->pushButton_35->show();
            ui->pushButton_36->show();
}

void home::on_pushButton_35_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_16->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET photo_6 = :photo WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home::on_pushButton_36_clicked()
{
    loadImageFromDatabase6();
    ui->label_26->show();
    ui->pushButton_44->show();
    i6= ui->lineEdit_12->text();
    QSqlQuery cap;
    cap.prepare("UPDATE post SET caption_6=:caption_6 WHERE username=:username");
    cap.bindValue(":caption_6", i6);
    cap.bindValue(":username", user);
    cap.exec();
}

void home::loadImageFromDatabase6() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_6 FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_16->setPixmap(pixmap);
        ui->label_16->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << user;
    }

    db.close();
}







void home::showImagePickerWindow7(QLabel *label26) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label26->setPixmap(pixmap);
        label26->setScaledContents(true);
    }
}

void home::on_pushButton_44_clicked()
{
    showImagePickerWindow7(ui->label_26);
    ui->pushButton_45->show();
    ui->pushButton_46->show();
}

void home::on_pushButton_45_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_26->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET photo_7 = :photo WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home::on_pushButton_46_clicked()
{
    loadImageFromDatabase7();
    ui->label_25->show();
    ui->pushButton_47->show();
    i7= ui->lineEdit_13->text();
    QSqlQuery cap;
    cap.prepare("UPDATE post SET caption_7=:caption_7 WHERE username=:username");
    cap.bindValue(":caption_7", i7);
    cap.bindValue(":username", user);
    cap.exec();
}

void home::loadImageFromDatabase7() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_7 FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_26->setPixmap(pixmap);
        ui->label_26->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << user;
    }

    db.close();
}






void home::showImagePickerWindow8(QLabel *label25) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label25->setPixmap(pixmap);
        label25->setScaledContents(true);
    }
}

void home::on_pushButton_47_clicked()
{
    showImagePickerWindow8(ui->label_25);
    ui->pushButton_48->show();
    ui->pushButton_49->show();
}

void home::on_pushButton_48_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_25->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET photo_8 = :photo WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home::on_pushButton_49_clicked()
{
    loadImageFromDatabase8();
    ui->label_27->show();
    ui->pushButton_50->show();
    i8= ui->lineEdit_14->text();
    QSqlQuery cap;
    cap.prepare("UPDATE post SET caption_8=:caption_8 WHERE username=:username");
    cap.bindValue(":caption_8", i8);
    cap.bindValue(":username", user);
    cap.exec();
}

void home::loadImageFromDatabase8() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_8 FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_25->setPixmap(pixmap);
        ui->label_25->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << user;
    }

    db.close();
}




void home::showImagePickerWindow9(QLabel *label27) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label27->setPixmap(pixmap);
        label27->setScaledContents(true);
    }
}

void home::on_pushButton_50_clicked()
{
    showImagePickerWindow9(ui->label_27);
    ui->pushButton_51->show();
    ui->pushButton_52->show();
}

void home::on_pushButton_51_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_27->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET photo_9 = :photo WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home::on_pushButton_52_clicked()
{
    loadImageFromDatabase9();
    ui->label_24->show();
    ui->pushButton_53->show();
    i9= ui->lineEdit_15->text();
    QSqlQuery cap;
    cap.prepare("UPDATE post SET caption_9=:caption_9 WHERE username=:username");
    cap.bindValue(":caption_9", i9);
    cap.bindValue(":username", user);
    cap.exec();

}

void home::loadImageFromDatabase9() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_9 FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_27->setPixmap(pixmap);
        ui->label_27->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << user;
    }

    db.close();
}





void home::showImagePickerWindow10(QLabel *label24) {
    QString fileName = QFileDialog::getOpenFileName(this,
        "انتخاب عکس", "", "تصاویر (*.png *.jpg *.jpeg)");

    if (!fileName.isEmpty()) {
        QPixmap pixmap(fileName);
        label24->setPixmap(pixmap);
        label24->setScaledContents(true);
    }
}

void home::on_pushButton_53_clicked()
{
    showImagePickerWindow10(ui->label_24);
    ui->pushButton_54->show();
    ui->pushButton_55->show();
}

void home::on_pushButton_54_clicked()
{
    // گرفتن QPixmap از QLabel
    const QPixmap *pixmapPtr = ui->label_24->pixmap();
    if (!pixmapPtr) {
        qDebug() << "No image in the label.";
        return;
    }
    QPixmap pixmap = *pixmapPtr; // تبدیل اشاره‌گر به QPixmap
    qDebug() << "Image successfully retrieved from QLabel.";

    // تبدیل QPixmap به QByteArray
    QByteArray byteArray;
    QBuffer buffer(&byteArray);
    buffer.open(QIODevice::WriteOnly);
    if (!pixmap.save(&buffer, "JPG")) {
        qDebug() << "Failed to save pixmap to buffer.";
        return;
    }
    qDebug() << "Pixmap successfully saved to buffer.";

    // اتصال به دیتابیس و ذخیره عکس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    QSqlQuery query;
    query.prepare("UPDATE post SET photo_10 = :photo WHERE username = :username");
    query.bindValue(":username", user);
    query.bindValue(":photo", byteArray);

    if(!query.exec()) {
        qDebug() << "Error: failed to update image in database: " << query.lastError();
    } else {
        qDebug() << "Image updated successfully";
    }

    db.close();
}

void home::on_pushButton_55_clicked()
{
    loadImageFromDatabase10();
    i10= ui->lineEdit_16->text();
    QSqlQuery cap;
    cap.prepare("UPDATE post SET caption_10=:caption_10 WHERE username=:username");
    cap.bindValue(":caption_10", i10);
    cap.bindValue(":username", user);
    cap.exec();
}

void home::loadImageFromDatabase10() {
    // اتصال به دیتابیس
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\linkedin2.db");

    if (!db.open()) {
        qDebug() << "Error: connection with database fail";
        return;
    } else {
        qDebug() << "Database: connection ok";
    }

    // اجرای کوئری برای خواندن عکس
    QSqlQuery query;
    query.prepare("SELECT photo_10 FROM post WHERE username = :username");
    query.bindValue(":username", user);

    if (!query.exec()) {
        qDebug() << "Error: failed to fetch image from database: " << query.lastError();
        return;
    }

    if (query.next()) {
        QByteArray byteArray = query.value(0).toByteArray();
        QPixmap pixmap;
        pixmap.loadFromData(byteArray);
        ui->label_24->setPixmap(pixmap);
        ui->label_24->setScaledContents(true);
    } else {
        qDebug() << "No image found for username: " << user;
    }

    db.close();
}









//****************my_network*****************






void home::on_pushButton_37_clicked()
{
    ui->groupBox_4->show();
    QSqlQuery query;
    query.exec("SELECT username FROM linkedin2 WHERE rf='"+user+"' OR rf='"+user_name+"'");
    QSqlQueryModel *n = new QSqlQueryModel;
    n->setQuery(query);
    ui->tableView_3->setModel(n);
}


void home::on_pushButton_40_clicked()
{
   QSqlQuery q;
   QString fo = ui->lineEdit_5->text();
   q.exec("SELECT follower FROM linkedin2 WHERE username ='"+user+"' OR username ='"+user_name+"'");
   QString tv;
   if (q.next()){
       tv = q.value(0).toString();
   }
   combined = fo + "/" + tv;
   QSqlQuery p;
   p.exec("UPDATE linkedin2 SET follower = '"+combined+"' WHERE username ='"+user+"' OR username ='"+user_name+"'");
}


void home::on_pushButton_38_clicked()
{
ui->groupBox_5->show();
QSqlQuery w;
w.exec("SELECT username FROM linkedin2 WHERE field='"+l6+"' OR field='"+f6+"'");
QSqlQueryModel *m = new QSqlQueryModel;
m->setQuery(w);
ui->tableView_4->setModel(m);
}


void home::on_pushButton_39_clicked()
{
    QSqlQuery q;
    QString fo = ui->lineEdit_6->text();
    q.exec("SELECT followed FROM linkedin2 WHERE username ='"+user+"' OR username ='"+user_name+"'");
    QString tv;
    if (q.next()){
        tv = q.value(0).toString();
    }
    mix = fo + "/" + tv;
    QSqlQuery p;
    p.exec("UPDATE linkedin2 SET followed = '"+mix+"' WHERE username ='"+user+"' OR username ='"+user_name+"'");
}


void home::on_pushButton_43_clicked()
{

    //ui->groupBox_11->show();
        QStringList followerList = combined.split("/");
            int count=0;

            if(count<followerList.size() ){
                QString username1 = followerList[count];
                QSqlQuery query;
                query.prepare("SELECT photo FROM post WHERE username = :username");
                query.bindValue(":username", username1);
                query.exec();
                if (query.next()) {
                    // دریافت داده عکس از دیتابیس
                    QByteArray imageData = query.value("photo").toByteArray();

                    // تبدیل داده عکس به QPixmap و نمایش در لیبل
                    QPixmap pixmap;
                    pixmap.loadFromData(imageData);
                    ui->label_22->setPixmap(pixmap);
                    ui->label_22->setScaledContents(true);

                }
                count++;


            }else{
                QMessageBox::information(this, "", "پستی نیست", "OK");
            }

            if(count < followerList.size()){
                    QString username2 = followerList[count];
                    QSqlQuery query;
                    query.prepare("SELECT photo FROM post WHERE username = :username");
                    query.bindValue(":username", username2);
                    query.exec();
                    if (query.next()) {
                        // دریافت داده عکس از دیتابیس
                        QByteArray imageData = query.value("photo").toByteArray();

                        // تبدیل داده عکس به QPixmap و نمایش در لیبل
                        QPixmap pixmap;
                        pixmap.loadFromData(imageData);
                        ui->label_23->setPixmap(pixmap);
                        ui->label_23->setScaledContents(true);

                    }
                    count++;
                }
            if(count < followerList.size()){
                QString username3 = followerList[count];
                QSqlQuery query;
                query.prepare("SELECT photo FROM post WHERE username = :username");
                query.bindValue(":username", username3);
                query.exec();
                if (query.next()) {
                    // دریافت داده عکس از دیتابیس
                    QByteArray imageData = query.value("photo").toByteArray();

                    // تبدیل داده عکس به QPixmap و نمایش در لیبل
                    QPixmap pixmap;
                    pixmap.loadFromData(imageData);
                    ui->label_32->setPixmap(pixmap);
                    ui->label_32->setScaledContents(true);

                }
                count++;

            }
            if(count < followerList.size()){
                QString username4 = followerList[count];
                QSqlQuery query;
                query.prepare("SELECT photo FROM post WHERE username = :username");
                query.bindValue(":username", username4);
                query.exec();
                if (query.next()) {
                    // دریافت داده عکس از دیتابیس
                    QByteArray imageData = query.value("photo").toByteArray();

                    // تبدیل داده عکس به QPixmap و نمایش در لیبل
                    QPixmap pixmap;
                    pixmap.loadFromData(imageData);
                    ui->label_35->setPixmap(pixmap);
                    ui->label_35->setScaledContents(true);

                }
                count++;
            }
            if(count < followerList.size()){
                QString username5 = followerList[count];
                QSqlQuery query;
                query.prepare("SELECT photo FROM post WHERE username = :username");
                query.bindValue(":username", username5);
                query.exec();
                if (query.next()) {
                    // دریافت داده عکس از دیتابیس
                    QByteArray imageData = query.value("photo").toByteArray();

                    // تبدیل داده عکس به QPixmap و نمایش در لیبل
                    QPixmap pixmap;
                    pixmap.loadFromData(imageData);
                    ui->label_36->setPixmap(pixmap);
                    ui->label_36->setScaledContents(true);

                }
                count++;

            }

}


void home::on_pushButton_41_clicked()
{
    QStringList flist = combined.split("/");
    QString name2 = flist[0];
    QSqlQuery q;
    q.exec("UPDATE linkedin2 SET rf = '"+name2+"' WHERE username = '"+user+"' OR username = '"+user_name+"'");
}


void home::on_pushButton_42_clicked()
{

    QStringList flist = combined.split("/");
      QString name3 = flist[0];
   QSqlQuery e;
   e.exec("SELECT like_number FROM post WHERE username = '"+name3+"'");
   int numb;
   if(e.next()){
       numb = e.value(0).toInt();
   }
   numb++;
   QSqlQuery query;
   query.prepare("UPDATE post SET like_number = :num1 WHERE username = :username");
   query.bindValue(":num1", numb);
   query.bindValue(":username", name3);

  QSqlQuery q;
  QString name_like;
  q.exec("SELECT like FROM post WHERE username = '"+name3+"'");

  if(q.next()){
      name_like = q.value(0).toString();
  }
  QString name_like1 = user_name + "/" + name_like;
  QSqlQuery P;
  P.exec("UPDATE post SET like ='"+name_like1+"' WHERE username = '"+name3+"'");
}


void home::on_pushButton_56_clicked()
{
    sign_company *w7 = new sign_company();
    w7->show();
      //this->close();
}


void home::on_pushButton_57_clicked()
{

    QStringList flist2 = combined.split("/");
        QString name4 = flist2[1];
        QSqlQuery Q;
        Q.exec("UPDATE linkedin2 SET rf = '"+user_name+"' WHERE username = '"+name4+"'");

}


void home::on_pushButton_59_clicked()
{

    QStringList flist3 = combined.split("/");
        QString name5 = flist3[2];
        QSqlQuery Q;
        Q.exec("UPDATE linkedin2 SET rf = '"+user_name+"' WHERE username = '"+name5+"'");

}


void home::on_pushButton_65_clicked()
{

    QStringList flist4 = combined.split("/");
        QString name6 = flist4[3];
        QSqlQuery Q;
        Q.exec("UPDATE linkedin2 SET rf = '"+user_name+"' WHERE username = '"+name6+"'");

}


void home::on_pushButton_67_clicked()
{
    QStringList flist5 = combined.split("/");
       QString name7 = flist5[4];
       QSqlQuery Q;
       Q.exec("UPDATE linkedin2 SET rf = '"+user_name+"' WHERE username = '"+name7+"'");


}


void home::on_pushButton_58_clicked()
{

    QStringList flist = combined.split("/");
      QString name4 = flist[1];
   QSqlQuery e;
   e.exec("SELECT like_number FROM post WHERE username = '"+name4+"'");
   int numb;
   if(e.next()){
       numb = e.value(0).toInt();
   }
   numb++;
   QSqlQuery query;
   query.prepare("UPDATE post SET like_number = :num1 WHERE username = :username");
   query.bindValue(":num1", numb);
   query.bindValue(":username", name4);

  QSqlQuery q;
  QString name_like;
  q.exec("SELECT like FROM post WHERE username = '"+name4+"'");

  if(q.next()){
      name_like = q.value(0).toString();
  }
  QString name_like1 = user_name + "/" + name_like;
  QSqlQuery P;
  P.exec("UPDATE post SET like ='"+name_like1+"' WHERE username = '"+name4+"'");
}


void home::on_pushButton_60_clicked()
{

    QStringList flist = combined.split("/");
       QString name7 = flist[2];
    QSqlQuery e;
    e.exec("SELECT like_number FROM post WHERE username = '"+name7+"'");
    int numb;
    if(e.next()){
        numb = e.value(0).toInt();
    }
    numb++;
    QSqlQuery query;
    query.prepare("UPDATE post SET like_number = :num1 WHERE username = :username");
    query.bindValue(":num1", numb);
    query.bindValue(":username", name7);

   QSqlQuery q;
   QString name_like;
   q.exec("SELECT like FROM post WHERE username = '"+name7+"'");

   if(q.next()){
       name_like = q.value(0).toString();
   }
   QString name_like1 = user_name + "/" + name_like;
   QSqlQuery P;
   P.exec("UPDATE post SET like ='"+name_like1+"' WHERE username = '"+name7+"'");

}


void home::on_pushButton_66_clicked()
{

    QStringList flist = combined.split("/");
        QString name8 = flist[3];
     QSqlQuery e;
     e.exec("SELECT like_number FROM post WHERE username = '"+name8+"'");
     int numb;
     if(e.next()){
         numb = e.value(0).toInt();
     }
     numb++;
     QSqlQuery query;
     query.prepare("UPDATE post SET like_number = :num1 WHERE username = :username");
     query.bindValue(":num1", numb);
     query.bindValue(":username", name8);

    QSqlQuery q;
    QString name_like;
    q.exec("SELECT like FROM post WHERE username = '"+name8+"'");

    if(q.next()){
        name_like = q.value(0).toString();
    }
    QString name_like1 = user_name + "/" + name_like;
    QSqlQuery P;
    P.exec("UPDATE post SET like ='"+name_like1+"' WHERE username = '"+name8+"'");
}


void home::on_pushButton_68_clicked()
{
    QStringList flist = combined.split("/");
      QString name9 = flist[4];
   QSqlQuery e;
   e.exec("SELECT like_number FROM post WHERE username = '"+name9+"'");
   int numb;
   if(e.next()){
       numb = e.value(0).toInt();
   }
   numb++;
   QSqlQuery query;
   query.prepare("UPDATE post SET like_number = :num1 WHERE username = :username");
   query.bindValue(":num1", numb);
   query.bindValue(":username", name9);

  QSqlQuery q;
  QString name_like;
  q.exec("SELECT like FROM post WHERE username = '"+name9+"'");

  if(q.next()){
      name_like = q.value(0).toString();
  }
  QString name_like1 = user_name + "/" + name_like;
  QSqlQuery P;
  P.exec("UPDATE post SET like ='"+name_like1+"' WHERE username = '"+name9+"'");
}


void home::on_pushButton_69_clicked()
{
    seemore_post *p = new seemore_post;
        p->show();
}


