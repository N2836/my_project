#include "page_search.h"
#include "ui_page_search.h"
#include "home.h"
#include <QFileDialog>
#include <QPixmap>
#include <QMessageBox>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlError>
#include <QByteArray>
#include <QBuffer>
#include <QSqlQuery>
#include <QByteArray>
#include <QBuffer>
#include <QLabel>
#include <QCompleter>
extern QString bio;
extern QString search;
extern QString user_name;
extern QString user;
//extern int dark;
page_search::page_search(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::page_search)
{
    ui->setupUi(this);
    ui->label->hide();
    ui->lineEdit->hide();



}

page_search::~page_search()
{
    delete ui;
}

void page_search::on_pushButton_2_clicked()
{
ui->label->show();
ui->lineEdit->show();


QSqlQuery o;
o.exec("SELECT username, post, field FROM linkedin2 WHERE username = '"+search+"'");


QSqlQueryModel *m = new QSqlQueryModel;
m->setQuery(o);
ui->tableView->setModel(m);






// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery query;
query.prepare("SELECT photo FROM post WHERE username = :username");
query.bindValue(":username", user_name);
query.exec();

if (query.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = query.value("photo").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label_2->setPixmap(pixmap);
    ui->label_2->setScaledContents(true);
}




// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery q;
q.prepare("SELECT photo_2 FROM post WHERE username = :username");
q.bindValue(":username", user_name);
q.exec();

if (q.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = q.value("photo_2").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label_3->setPixmap(pixmap);
    ui->label_3->setScaledContents(true);
}





// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery f;
f.prepare("SELECT photo_3 FROM post WHERE username = :username");
f.bindValue(":username", user_name);
f.exec();

if (f.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = f.value("photo_3").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label_4->setPixmap(pixmap);
    ui->label_4->setScaledContents(true);
}




// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery d;
d.prepare("SELECT photo_4 FROM post WHERE username = :username");
d.bindValue(":username", user_name);
d.exec();

if (d.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = d.value("photo_4").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label_5->setPixmap(pixmap);
    ui->label_5->setScaledContents(true);
}






// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery s;
s.prepare("SELECT photo_5 FROM post WHERE username = :username");
s.bindValue(":username", user_name);
s.exec();

if (s.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = s.value("photo_5").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label_6->setPixmap(pixmap);
    ui->label_6->setScaledContents(true);
}





// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery w;
w.prepare("SELECT photo_6 FROM post WHERE username = :username");
w.bindValue(":username", user_name);
w.exec();

if (w.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = w.value("photo_6").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label_7->setPixmap(pixmap);
    ui->label_7->setScaledContents(true);
}



// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery a;
a.prepare("SELECT photo_7 FROM post WHERE username = :username");
a.bindValue(":username", user_name);
a.exec();

if (a.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = a.value("photo_7").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label_8->setPixmap(pixmap);
    ui->label_8->setScaledContents(true);
}



// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery g;
g.prepare("SELECT photo_8 FROM post WHERE username = :username");
g.bindValue(":username", user_name);
g.exec();

if (g.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = g.value("photo_8").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label_9->setPixmap(pixmap);
    ui->label_9->setScaledContents(true);
}



// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery x;
x.prepare("SELECT photo_9 FROM post WHERE username = :username");
x.bindValue(":username", user_name);
x.exec();

if (x.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = x.value("photo_9").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label_10->setPixmap(pixmap);
    ui->label_10->setScaledContents(true);
}


// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery z;
z.prepare("SELECT photo_10 FROM post WHERE username = :username");
z.bindValue(":username", user_name);
z.exec();

if (z.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = z.value("photo_10").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label_11->setPixmap(pixmap);
    ui->label_11->setScaledContents(true);
}




/*
QSqlQuery u;
u.exec("SELECT skil FROM job WHERE username = '"+search+"'");


QSqlQueryModel *j= new QSqlQueryModel;
j->setQuery(u);
ui->tableView_2->setModel(j);
*/



/*
ui->lineEdit->setText(bio);
ui->lineEdit->setReadOnly(true);
QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
db.setDatabaseName("linkedin2.db");
db.open();
*/



/*
// ایجاد کوئری برای دریافت عکس
QSqlQuery query;
query.exec("SELECT profile FROM linkedin2 WHERE username ='"+search+"'");
//query.bindValue(":search", search);
if (!query.exec()) {
    qDebug() << "Query error:" << query.lastError().text();
    return;
}

// اگر نتیجه‌ای پیدا شد
if (query.next()) {
    // دریافت داده‌های عکس
    QByteArray imageData = query.value(0).toByteArray();
    // ایجاد QPixmap از داده‌های عکس
    QPixmap pixmap;
    if (!pixmap.loadFromData(imageData)) {
        qDebug() << "Error loading image data";
        return;
    }

    // تنظیم عکس در لیبل
    ui->label->setPixmap(pixmap);
    ui->label->setScaledContents(true); // تنظیم اندازه عکس با توجه به اندازه لیبل
} else {
    qDebug() << "No results found";
}
*/


// پرس و جو برای دریافت عکس مربوط به کاربر
QSqlQuery t;
t.prepare("SELECT photo FROM post WHERE username = :username");
t.bindValue(":username", search);
t.exec();

if (t.next()) {
    // دریافت داده عکس از دیتابیس
    QByteArray imageData = t.value("photo").toByteArray();

    // تبدیل داده عکس به QPixmap و نمایش در لیبل
    QPixmap pixmap;
    pixmap.loadFromData(imageData);
    ui->label->setPixmap(pixmap);
    ui->label->setScaledContents(true);
}

// db.close();

// بستن اتصال به دیتابیس
//db.close();

}




void page_search::on_pushButton_3_clicked()
{
    QSqlQuery q;
   q.exec("UPDATE linkedin2 SET rf = '"+search+"' WHERE username = '"+user+"' OR username = '"+user_name+"'");
}

