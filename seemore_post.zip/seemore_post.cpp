#include "seemore_post.h"
#include "ui_seemore_post.h"
#include "home.h"
#include <QFileDialog>
#include <QPixmap>
#include <QMessageBox>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlError>
#include <QByteArray>
#include <QBuffer>
#include <QLabel>
#include <QVBoxLayout>
#include <QMediaPlayer>
#include <QVideoWidget>
#include <QGraphicsVideoItem>
#include <QAbstractVideoSurface>
#include <vector>

QString combined;
extern QString user_name;
extern QString user;
QByteArray byteArray;

//extern int dark;

seemore_post::seemore_post(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::seemore_post)
{
    ui->setupUi(this);
}

seemore_post::~seemore_post()
{
    delete ui;
}

void seemore_post::on_pushButton_clicked()
{
    //ui->groupBox_11->show();
        QStringList followerList = combined.split("/");
            int count=0;

            if(count<followerList.size() ){
                QString username1 = followerList[count];
                QSqlQuery query;
                query.prepare("SELECT photo FROM post WHERE username = :username");
                query.bindValue(":username", username1);
                query.exec();
                if (query.next()) {
                    // دریافت داده عکس از دیتابیس
                    QByteArray imageData = query.value("photo").toByteArray();

                    // تبدیل داده عکس به QPixmap و نمایش در لیبل
                    QPixmap pixmap;
                    pixmap.loadFromData(imageData);
                    ui->label_42->setPixmap(pixmap);
                    ui->label_42->setScaledContents(true);

                }
                count++;


            }else{
                QMessageBox::information(this, "", "پستی نیست", "OK");
            }

            if(count < followerList.size()){
                    QString username2 = followerList[count];
                    QSqlQuery query;
                    query.prepare("SELECT photo FROM post WHERE username = :username");
                    query.bindValue(":username", username2);
                    query.exec();
                    if (query.next()) {
                        // دریافت داده عکس از دیتابیس
                        QByteArray imageData = query.value("photo").toByteArray();

                        // تبدیل داده عکس به QPixmap و نمایش در لیبل
                        QPixmap pixmap;
                        pixmap.loadFromData(imageData);
                        ui->label_38->setPixmap(pixmap);
                        ui->label_38->setScaledContents(true);

                    }
                    count++;
                }
            if(count < followerList.size()){
                QString username3 = followerList[count];
                QSqlQuery query;
                query.prepare("SELECT photo FROM post WHERE username = :username");
                query.bindValue(":username", username3);
                query.exec();
                if (query.next()) {
                    // دریافت داده عکس از دیتابیس
                    QByteArray imageData = query.value("photo").toByteArray();

                    // تبدیل داده عکس به QPixmap و نمایش در لیبل
                    QPixmap pixmap;
                    pixmap.loadFromData(imageData);
                    ui->label_39->setPixmap(pixmap);
                    ui->label_39->setScaledContents(true);

                }
                count++;

            }
            if(count < followerList.size()){
                QString username4 = followerList[count];
                QSqlQuery query;
                query.prepare("SELECT photo FROM post WHERE username = :username");
                query.bindValue(":username", username4);
                query.exec();
                if (query.next()) {
                    // دریافت داده عکس از دیتابیس
                    QByteArray imageData = query.value("photo").toByteArray();

                    // تبدیل داده عکس به QPixmap و نمایش در لیبل
                    QPixmap pixmap;
                    pixmap.loadFromData(imageData);
                    ui->label_40->setPixmap(pixmap);
                    ui->label_40->setScaledContents(true);

                }
                count++;
            }
            if(count < followerList.size()){
                QString username5 = followerList[count];
                QSqlQuery query;
                query.prepare("SELECT photo FROM post WHERE username = :username");
                query.bindValue(":username", username5);
                query.exec();
                if (query.next()) {
                    // دریافت داده عکس از دیتابیس
                    QByteArray imageData = query.value("photo").toByteArray();

                    // تبدیل داده عکس به QPixmap و نمایش در لیبل
                    QPixmap pixmap;
                    pixmap.loadFromData(imageData);
                    ui->label_41->setPixmap(pixmap);
                    ui->label_41->setScaledContents(true);

                }
                count++;

            }

}


void seemore_post::on_pushButton_79_clicked()
{
    QStringList flist = combined.split("/");
    QString name2 = flist[5];
    QSqlQuery q;
    q.exec("UPDATE linkedin2 SET rf = '"+name2+"' WHERE username = '"+user+"' OR username = '"+user_name+"'");
}


void seemore_post::on_pushButton_80_clicked()
{
    QStringList flist = combined.split("/");
          QString name3 = flist[0];
       QSqlQuery e;
       e.exec("SELECT like_number FROM post WHERE username = '"+name3+"'");
       int numb;
       if(e.next()){
           numb = e.value(0).toInt();
       }
       numb++;
       QSqlQuery query;
       query.prepare("UPDATE post SET like_number = :num1 WHERE username = :username");
       query.bindValue(":num1", numb);
       query.bindValue(":username", name3);

      QSqlQuery q;
      QString name_like;
      q.exec("SELECT like FROM post WHERE username = '"+name3+"'");

      if(q.next()){
          name_like = q.value(0).toString();
      }
      QString name_like1 = user_name + "/" + name_like;
      QSqlQuery P;
      P.exec("UPDATE post SET like ='"+name_like1+"' WHERE username = '"+name3+"'");



}


void seemore_post::on_pushButton_71_clicked()
{
    QStringList flist2 = combined.split("/");
            QString name4 = flist2[6];
            QSqlQuery Q;
            Q.exec("UPDATE linkedin2 SET rf = '"+user_name+"' WHERE username = '"+name4+"'");


}


void seemore_post::on_pushButton_72_clicked()
{

    QStringList flist = combined.split("/");
         QString name4 = flist[1];
      QSqlQuery e;
      e.exec("SELECT like_number FROM post WHERE username = '"+name4+"'");
      int numb;
      if(e.next()){
          numb = e.value(0).toInt();
      }
      numb++;
      QSqlQuery query;
      query.prepare("UPDATE post SET like_number = :num1 WHERE username = :username");
      query.bindValue(":num1", numb);
      query.bindValue(":username", name4);

     QSqlQuery q;
     QString name_like;
     q.exec("SELECT like FROM post WHERE username = '"+name4+"'");

     if(q.next()){
         name_like = q.value(0).toString();
     }
     QString name_like1 = user_name + "/" + name_like;
     QSqlQuery P;
     P.exec("UPDATE post SET like ='"+name_like1+"' WHERE username = '"+name4+"'");


}


void seemore_post::on_pushButton_73_clicked()
{

    QStringList flist3 = combined.split("/");
           QString name5 = flist3[7];
           QSqlQuery Q;
           Q.exec("UPDATE linkedin2 SET rf = '"+user_name+"' WHERE username = '"+name5+"'");
}


void seemore_post::on_pushButton_74_clicked()
{
    QStringList flist = combined.split("/");
          QString name7 = flist[2];
       QSqlQuery e;
       e.exec("SELECT like_number FROM post WHERE username = '"+name7+"'");
       int numb;
       if(e.next()){
           numb = e.value(0).toInt();
       }
       numb++;
       QSqlQuery query;
       query.prepare("UPDATE post SET like_number = :num1 WHERE username = :username");
       query.bindValue(":num1", numb);
       query.bindValue(":username", name7);

      QSqlQuery q;
      QString name_like;
      q.exec("SELECT like FROM post WHERE username = '"+name7+"'");

      if(q.next()){
          name_like = q.value(0).toString();
      }
      QString name_like1 = user_name + "/" + name_like;
      QSqlQuery P;
      P.exec("UPDATE post SET like ='"+name_like1+"' WHERE username = '"+name7+"'");



}


void seemore_post::on_pushButton_75_clicked()
{

    QStringList flist4 = combined.split("/");
           QString name6 = flist4[8];
           QSqlQuery Q;
           Q.exec("UPDATE linkedin2 SET rf = '"+user_name+"' WHERE username = '"+name6+"'");


}


void seemore_post::on_pushButton_76_clicked()
{
    QStringList flist = combined.split("/");
          QString name8 = flist[3];
       QSqlQuery e;
       e.exec("SELECT like_number FROM post WHERE username = '"+name8+"'");
       int numb;
       if(e.next()){
           numb = e.value(0).toInt();
       }
       numb++;
       QSqlQuery query;
       query.prepare("UPDATE post SET like_number = :num1 WHERE username = :username");
       query.bindValue(":num1", numb);
       query.bindValue(":username", name8);

      QSqlQuery q;
      QString name_like;
      q.exec("SELECT like FROM post WHERE username = '"+name8+"'");

      if(q.next()){
          name_like = q.value(0).toString();
      }
      QString name_like1 = user_name + "/" + name_like;
      QSqlQuery P;
      P.exec("UPDATE post SET like ='"+name_like1+"' WHERE username = '"+name8+"'");


}


void seemore_post::on_pushButton_77_clicked()
{

    QStringList flist5 = combined.split("/");
           QString name7 = flist5[9];
           QSqlQuery Q;
           Q.exec("UPDATE linkedin2 SET rf = '"+user_name+"' WHERE username = '"+name7+"'");


}


void seemore_post::on_pushButton_78_clicked()
{

    QStringList flist = combined.split("/");
         QString name9 = flist[4];
      QSqlQuery e;
      e.exec("SELECT like_number FROM post WHERE username = '"+name9+"'");
      int numb;
      if(e.next()){
          numb = e.value(0).toInt();
      }
      numb++;
      QSqlQuery query;
      query.prepare("UPDATE post SET like_number = :num1 WHERE username = :username");
      query.bindValue(":num1", numb);
      query.bindValue(":username", name9);

     QSqlQuery q;
     QString name_like;
     q.exec("SELECT like FROM post WHERE username = '"+name9+"'");

     if(q.next()){
         name_like = q.value(0).toString();
     }
     QString name_like1 = user_name + "/" + name_like;
     QSqlQuery P;
     P.exec("UPDATE post SET like ='"+name_like1+"' WHERE username = '"+name9+"'");
}

